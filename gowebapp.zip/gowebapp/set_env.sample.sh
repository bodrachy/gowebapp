#!/bin/bash

#default profile
export DATABASE_NAME="dbname"
export DATABASE_USERNAME="username"
export DATABASE_PASSWORD="password"
export DATABASE_SERVER="localhost"
export DATABASE_PORT="3306"


echo "All set!"